function getArticles() {
  var articles = [  {"name": "first article","id": "first_article","category": "articles","url": "articles/article_article1.html"},
  {"name": "faq","id": "faq","category": "articles","url": "articles/article_FAQ_article.html"},
  {"name": "second article","id": "second_article","category": "articles","url": "articles/article_article2.html"},
  {"name": "mediawiki article","id": "mediawiki_article","category": "articles","url": "articles/article_Mediawiki.html"}]
  return articles;
}