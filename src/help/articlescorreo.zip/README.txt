Help content generated for Swing
